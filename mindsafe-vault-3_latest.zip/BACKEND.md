
# MindSafe Vault - Backend Implementation Guide

This document outlines the Python/FastAPI structure that complements the React frontend.

## 1. Project Structure
```text
mindsafe-vault/
├── backend/
│   ├── main.py            # FastAPI entry point
│   ├── models/            # Pydantic schemas
│   ├── services/
│   │   ├── crypto.py      # AES-256 logic
│   │   ├── risk.py        # Risk scoring logic
│   │   └── ledger.py      # Immutable logging
│   └── database/          # MongoDB / Mock storage
└── frontend/ (React)
```

## 2. Risk Scoring Logic (Python)
```python
from pydantic import BaseModel
from typing import Optional, Literal

class CheckIn(BaseModel):
    mood: int  # 1-5
    stress: Literal['low', 'medium', 'high']
    sleep_hours: float
    reflection: Optional[str]

def calculate_risk(entry: CheckIn):
    # Mood normalization
    mood_score = (5 - entry.mood) * 25
    
    # Stress mapping
    stress_map = {'low': 0, 'medium': 50, 'high': 100}
    stress_score = stress_map[entry.stress]
    
    # Sleep factor
    sleep_score = 100 if entry.sleep_hours < 6 else (50 if entry.sleep_hours < 7 else 0)
    
    # Weights: 40/40/20
    score = (mood_score * 0.4) + (stress_score * 0.4) + (sleep_score * 0.2)
    
    level = "Low"
    if score >= 70: level = "High"
    elif score >= 40: level = "Moderate"
    
    return {"score": round(score), "level": level}
```

## 3. Security Decisions
- **AES-256-GCM:** Used for all "Reflection" fields. The user's key is never stored in plaintext on the server.
- **Token Expiry:** Shared counselor tokens use Redis-based TTL for automatic expiration.
- **Privacy Masking:** Counselor API endpoints explicitly filter out identifiable strings, returning only numeric trends.

## 4. Ethical Safeguards
- **Non-Diagnostic:** The risk levels are labeled "Early Warning Indicators" rather than "Clinical Diagnoses".
- **Student Sovereignty:** Data sharing is pull-based (counselor requires token) rather than push-based (forced alerts).
