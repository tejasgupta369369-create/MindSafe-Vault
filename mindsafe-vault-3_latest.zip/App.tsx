
import React, { useState, useEffect, useMemo } from 'react';
import { User, CheckInEntry, AccessLog, RiskLevel, CounselorFeedback, PatientQuestion } from './types';
import { API } from './services/mockApi';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar, Cell } from 'recharts';
import { GoogleGenAI } from "@google/genai";

// --- Pro UI Components ---

const GlassCard: React.FC<{ 
  children: React.ReactNode, 
  title?: string, 
  subtitle?: string, 
  accent?: 'indigo' | 'emerald' | 'rose' | 'amber' | 'slate',
  noPadding?: boolean,
  className?: string
}> = ({ children, title, subtitle, accent = 'indigo', noPadding, className = "" }) => {
  const accentClasses = {
    indigo: 'border-indigo-100',
    emerald: 'border-emerald-100',
    rose: 'border-rose-100',
    amber: 'border-amber-100',
    slate: 'border-slate-200'
  };

  return (
    <div className={`bg-white rounded-[2.5rem] shadow-sm border ${accentClasses[accent]} overflow-hidden mb-8 transition-all duration-500 hover:shadow-2xl hover:-translate-y-1 animate-in fade-in slide-in-from-bottom-8 ${className}`}>
      {title && (
        <div className="px-10 py-8 border-b border-slate-50 text-left">
          <h3 className="font-black text-slate-900 text-2xl tracking-tight leading-none mb-2">{title}</h3>
          {subtitle && <p className="text-xs text-slate-400 font-bold uppercase tracking-[0.2em]">{subtitle}</p>}
        </div>
      )}
      <div className={noPadding ? '' : 'p-10'}>{children}</div>
    </div>
  );
};

const StatMetric: React.FC<{ label: string, value: string | number, sub: string, color: string, icon: React.ReactNode }> = ({ label, value, sub, color, icon }) => (
  <div className="bg-slate-50/50 p-8 rounded-[2rem] border border-slate-100 transition-all hover:bg-white hover:shadow-lg group relative overflow-hidden text-left">
    <div className="absolute top-0 right-0 p-4 opacity-5 group-hover:opacity-10 transition-opacity">
      {icon}
    </div>
    <p className="text-[11px] font-black uppercase tracking-[0.2em] text-slate-400 mb-3 group-hover:text-indigo-600 transition-colors">{label}</p>
    <div className={`text-4xl font-black ${color} tracking-tighter mb-2`}>{value}</div>
    <p className="text-[11px] font-bold text-slate-400/80">{sub}</p>
  </div>
);

const PillarCard: React.FC<{ icon: React.ReactNode, title: string, description: string, delay: string }> = ({ icon, title, description, delay }) => (
  <div className={`p-10 bg-white border border-slate-100 rounded-[3rem] shadow-sm hover:shadow-2xl transition-all duration-500 hover:-translate-y-2 animate-in fade-in slide-in-from-bottom-12 ${delay} text-left`}>
    <div className="w-16 h-16 bg-indigo-50 text-indigo-600 rounded-2xl flex items-center justify-center mb-8 shadow-inner">
      {icon}
    </div>
    <h3 className="text-xl font-black text-slate-900 mb-4 tracking-tight">{title}</h3>
    <p className="text-slate-500 font-medium leading-relaxed">{description}</p>
  </div>
);

const Icons = {
  Sleep: () => <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-16 h-16"><path d="M11.25 4.533A9.707 9.707 0 0 0 6 3a9.735 9.735 0 0 0-3.25.555.75.75 0 0 0-.5.707v14.25a.75.75 0 0 0 1 .707A8.237 8.237 0 0 1 6 18.75c1.995 0 3.823.707 5.25 1.886V4.533ZM12.75 20.636A8.214 8.214 0 0 1 18 18.75c.966 0 1.89.166 2.75.47a.75.75 0 0 0 1-.708V4.262a.75.75 0 0 0-.5-.707A9.735 9.735 0 0 0 18 3a9.707 9.707 0 0 0-5.25 1.533v16.103Z" /></svg>,
  Energy: () => <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-16 h-16"><path fillRule="evenodd" d="M14.615 1.595a.75.75 0 0 1 .359.852L12.982 9.75h7.268a.75.75 0 0 1 .548 1.262l-10.5 11.25a.75.75 0 0 1-1.272-.71l1.992-7.302H3.75a.75.75 0 0 1-.548-1.262l10.5-11.25a.75.75 0 0 1 .913-.143Z" clipRule="evenodd" /></svg>,
  Anxiety: () => <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-16 h-16"><path fillRule="evenodd" d="M9.401 3.003c1.155-2 4.043-2 5.197 0l7.355 12.748c1.154 2-.29 4.5-2.599 4.5H4.645c-2.309 0-3.752-2.5-2.598-4.5L9.401 3.003ZM12 8.25a.75.75 0 0 1 .75.75v3.75a.75.75 0 0 1-1.5 0V9a.75.75 0 0 1 .75-.75Zm0 8.25a.75.75 0 1 0 0-1.5.75.75 0 0 0 0 1.5Z" clipRule="evenodd" /></svg>,
  Social: () => <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-16 h-16"><path d="M4.5 6.375a4.125 4.125 0 1 1 8.25 0 4.125 4.125 0 0 1-8.25 0ZM14.25 8.625a3.375 3.375 0 1 1 6.75 0 3.375 3.375 0 0 1-6.75 0ZM1.5 19.125a7.125 7.125 0 0 1 14.25 0v.003l-.001.119a.75.75 0 0 1-.363.63 13.067 13.067 0 0 1-6.761 1.873c-2.472 0-4.786-.684-6.76-1.873a.75.75 0 0 1-.364-.63l-.001-.122ZM17.25 19.125a7.125 7.125 0 0 1 14.25 0v.003l-.001.119a.75.75 0 0 1-.363.63 13.067 13.067 0 0 1-6.761 1.873c-2.472 0-4.786-.684-6.76-1.873a.75.75 0 0 1-.364-.63l-.001-.122Z" /></svg>,
  Privacy: () => <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-8 h-8"><path fillRule="evenodd" d="M12 1.5a5.25 5.25 0 0 0-5.25 5.25v3a3 3 0 0 0-3 3v6.75a3 3 0 0 0 3 3h10.5a3 3 0 0 0 3-3v-6.75a3 3 0 0 0-3-3v-3A5.25 5.25 0 0 0 12 1.5Zm-3.75 8.25v-3a3.75 3.75 0 1 1 7.5 0v3H8.25Z" clipRule="evenodd" /></svg>,
  Intelligence: () => <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-8 h-8"><path fillRule="evenodd" d="M9 4.5a.75.75 0 0 1 .721.544l.813 2.846a3.75 3.75 0 0 0 2.576 2.576l2.846.813a.75.75 0 0 1 0 1.442l-2.846.813a3.75 3.75 0 0 0-2.576 2.576l-.813 2.846a.75.75 0 0 1-1.442 0l-.813-2.846a3.75 3.75 0 0 0-2.576-2.576l-2.846-.813a.75.75 0 0 1 0-1.442l2.846-.813a3.75 3.75 0 0 0 2.576-2.576l.813-2.846A.75.75 0 0 1 9 4.5ZM19.321 12.423a.75.75 0 0 1 .658.077l.059.045a.75.75 0 0 1 .018 1.15l-1.321 1.32a.75.75 0 0 0-.218.44l-.273 1.89a.75.75 0 0 1-1.17.521l-1.623-.962a.75.75 0 0 0-.54 0l-1.623.962a.75.75 0 0 1-1.17-.521l-.273-1.89a.75.75 0 0 0-.218-.44l-1.321-1.32a.75.75 0 0 1 .018-1.15l.059-.045a.75.75 0 0 1 .658-.077l1.91.764a.75.75 0 0 0 .54 0l1.91-.764Z" clipRule="evenodd" /></svg>,
  Interoperable: () => <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-8 h-8"><path d="M16.5 6a3 3 0 0 0-3-3H6a3 3 0 0 0-3 3v7.5a3 3 0 0 0 3 3h7.5a3 3 0 0 0 3-3V6Z" /><path d="M20.25 9a.75.75 0 0 0-.75.75V12a3 3 0 0 1-3 3h-2.25a.75.75 0 0 0 0 1.5H17.25A4.5 4.5 0 0 0 21.75 12V9.75a.75.75 0 0 0-.75-.75Z" /><path d="M10.5 20.25a.75.75 0 0 0-1.5 0V21a.75.75 0 0 0 1.5 0v-.75Z" /></svg>
};

// --- Main Application ---

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [view, setView] = useState<'landing' | 'login' | 'consent' | 'dashboard' | 'checkin' | 'counselor' | 'logs'>('landing');
  const [entries, setEntries] = useState<CheckInEntry[]>([]);
  const [feedback, setFeedback] = useState<CounselorFeedback[]>([]);
  const [questions, setQuestions] = useState<PatientQuestion[]>([]);
  const [logs, setLogs] = useState<AccessLog[]>([]);
  const [token, setToken] = useState<string | null>(null);
  const [counselorData, setCounselorData] = useState<any>(null);
  const [searchToken, setSearchToken] = useState('');
  const [aiAdvice, setAiAdvice] = useState<string[]>([]);
  const [counselorAiSummary, setCounselorAiSummary] = useState<string>('');
  const [isAiLoading, setIsAiLoading] = useState(false);
  const [isCounselorAiLoading, setIsCounselorAiLoading] = useState(false);
  
  const [newQuestion, setNewQuestion] = useState('');
  const [checkInReflection, setCheckInReflection] = useState('');
  const [doctorNote, setDoctorNote] = useState('');
  const [doctorName, setDoctorName] = useState('Sarah Jenkins');
  const [doctorTitle, setDoctorTitle] = useState('PhD, Clinical Lead');
  const [doctorSpecialty, setDoctorSpecialty] = useState('Anxiety & Cognitive Health');
  const [doctorDepartment, setDoctorDepartment] = useState('Campus Health Services');
  const [doctorInterventions, setDoctorInterventions] = useState<string[]>([]);
  const [activeQuestionId, setActiveQuestionId] = useState<string | null>(null);
  const [isEditingProfile, setIsEditingProfile] = useState(false);

  const lastEntry = useMemo(() => entries[entries.length - 1], [entries]);

  // Force chart data mapping
  const chartData = useMemo(() => {
    return entries.map((e, idx) => ({
      name: `Entry ${idx + 1}`,
      date: new Date(e.timestamp).toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
      score: e.riskScore || 0
    }));
  }, [entries]);

  useEffect(() => {
    if (user && view === 'dashboard') {
      API.getDashboard(user.id).then(data => {
        setEntries(data.entries);
        setFeedback(data.feedback);
        setQuestions(data.questions);
        fetchAiInsights(data.entries);
      });
    }
    if (view === 'logs') API.getLogs().then(setLogs);
  }, [user, view]);

  const fetchAiInsights = async (currentEntries: CheckInEntry[]) => {
    if (currentEntries.length === 0) return;
    setIsAiLoading(true);
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const latest = currentEntries[currentEntries.length - 1];
      const prompt = `Student Wellness Snapshot: Mood ${latest.mood}/5, Stress ${latest.stress}. Act as a supportive, warm wellness companion. Provide exactly 3 personalized, insightful, and thoughtful pieces of advice. Each item should be 1-2 full sentences that feel supportive and encouraging. No ultra-short directives. Be empathetic. Avoid generic medical advice; focus on resilience.`;
      
      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: prompt
      });
      
      const text = response.text || "";
      setAiAdvice(text.split('\n').filter(l => l.trim().length > 10).slice(0, 3));
    } catch (e) {
      setAiAdvice([
        "Try to find a small moment for yourself today; even a five-minute stretch can make a difference.",
        "Your feelings are valid, and it is okay to move at your own pace while navigating stress.",
        "Remember that prioritizing rest is not just okay, it is essential for your long-term resilience."
      ]);
    } finally {
      setIsAiLoading(false);
    }
  };

  const fetchCounselorSummary = async (tokenData: any) => {
    if (!tokenData || tokenData.riskTrend.length === 0) return;
    setIsCounselorAiLoading(true);
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const trendData = tokenData.riskTrend.slice(-7);
      const prompt = `Student ID: ${tokenData.ownerId}. Risk Trend Score: ${trendData.map((d: any) => d.score).join(', ')}. Status: ${tokenData.currentRiskLevel}. Clinical Briefing: Provide a highly professional, clinical 2-sentence reasoning for a medical practitioner summarizing the patient's trajectory and immediate focus areas. No fluff.`;
      
      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: prompt
      });
      
      setCounselorAiSummary(response.text || "Trend analysis indicates stable baseline.");
    } catch (e) {
      setCounselorAiSummary("Stable.");
    } finally {
      setIsCounselorAiLoading(false);
    }
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    const loggedIn = await API.login('demo@college.edu');
    if (loggedIn) {
      setUser(loggedIn);
      setView(loggedIn.hasConsented ? 'dashboard' : 'consent');
    }
  };

  const handleCheckIn = async (formData: any) => {
    if (user) {
      await API.submitCheckIn(user.id, formData);
      setCheckInReflection('');
      setView('dashboard');
    }
  };

  const submitQuestion = async () => {
    if (user && newQuestion.trim()) {
      await API.submitPatientQuestion(user.id, newQuestion);
      setNewQuestion('');
      API.getDashboard(user.id).then(data => setQuestions(data.questions));
    }
  };

  const handleConsent = async (val: boolean) => {
    if (user && val) {
      await API.updateConsent(user.id, true);
      setUser({ ...user, hasConsented: true });
      setView('dashboard');
    } else {
      setView('login');
    }
  };

  const submitClinicalNote = async () => {
    if (counselorData && (doctorNote || doctorInterventions.length > 0)) {
      await API.submitCounselorFeedback(
        counselorData.ownerId, 
        doctorName, 
        doctorTitle, 
        doctorSpecialty, 
        doctorDepartment, 
        doctorNote, 
        doctorInterventions,
        activeQuestionId || undefined
      );
      alert("Note successfully synced to vault.");
      setDoctorNote('');
      setDoctorInterventions([]);
      setActiveQuestionId(null);
      setCounselorData(null);
      setCounselorAiSummary('');
      // Refresh student dashboard data if they are still on it (though usually doctor and student are different sessions)
      if (user) API.getDashboard(user.id).then(data => { setFeedback(data.feedback); setQuestions(data.questions); });
    }
  };

  // --- Specialized Render Methods ---

  const renderLanding = () => (
    <div className="min-h-screen bg-slate-50 overflow-x-hidden">
      <section className="relative pt-24 pb-32 px-10">
        <div className="max-w-6xl mx-auto text-center relative z-10">
          <div className="w-24 h-24 bg-gradient-to-br from-indigo-600 to-indigo-900 rounded-[2.5rem] shadow-2xl flex items-center justify-center text-white font-black text-4xl mx-auto mb-10 animate-in zoom-in duration-1000">M</div>
          <h1 className="text-8xl font-black text-slate-900 tracking-tighter leading-none mb-8 animate-in slide-in-from-top-12 duration-700">MindSafe <span className="text-indigo-600">Vault</span></h1>
          <p className="text-2xl font-black text-slate-400 uppercase tracking-[0.4em] mb-12 animate-in fade-in duration-1000 delay-300">Data Sovereignty. Resilience. Privacy.</p>
          <div className="flex justify-center gap-6 animate-in slide-in-from-bottom-12 duration-1000 delay-700">
            <button onClick={() => setView('login')} className="bg-indigo-600 text-white px-12 py-6 rounded-[2.5rem] font-black text-xl shadow-2xl shadow-indigo-200 hover:bg-indigo-700 hover:-translate-y-1 transition-all">Access Vault</button>
            <button onClick={() => setView('counselor')} className="bg-white border-2 border-slate-100 text-slate-900 px-12 py-6 rounded-[2.5rem] font-black text-xl hover:bg-slate-50 transition-all">Practitioner Terminal</button>
          </div>
        </div>
      </section>
      <section className="max-w-7xl mx-auto px-10 pb-48">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-12 text-left">
          <PillarCard delay="delay-0" icon={<Icons.Privacy />} title="Encrypted Sovereignty" description="Reflections locked at source. MindSafe cannot decrypt your internal dialogue." />
          <PillarCard delay="delay-300" icon={<Icons.Intelligence />} title="Heuristic Risk Engine" description="Weighted algorithms detect stress indicators before they escalate." />
          <PillarCard delay="delay-500" icon={<Icons.Interoperable />} title="Clinical Synchronicity" description="Share trends using temporary keys. Maintain total privacy." />
        </div>
      </section>
    </div>
  );

  const renderDashboard = () => (
    <div className="min-h-screen bg-[#FDFDFF]">
      <nav className="bg-white/90 backdrop-blur-2xl border-b border-slate-100 px-12 py-7 flex items-center justify-between sticky top-0 z-40">
        <div className="flex items-center gap-5">
          <div className="w-14 h-14 bg-gradient-to-br from-indigo-600 to-indigo-800 rounded-2xl shadow-xl flex items-center justify-center text-white font-black text-xl">M</div>
          <div className="text-left"><h2 className="text-2xl font-black text-slate-900 tracking-tighter leading-none mb-1 text-left">MindSafe <span className="text-indigo-600 italic">Vault</span></h2><p className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-400 text-left">Vault Session Active</p></div>
        </div>
        <div className="flex items-center gap-10">
          <button onClick={() => setView('logs')} className="text-slate-400 hover:text-indigo-600 font-black text-[11px] uppercase tracking-widest transition-all">Audit ledger</button>
          <button onClick={() => setView('login')} className="bg-rose-50 text-rose-600 px-8 py-3 rounded-2xl font-black text-[11px] uppercase tracking-widest hover:bg-rose-100 transition-all border border-rose-100/50">Lock Vault</button>
        </div>
      </nav>
      <main className="max-w-7xl mx-auto px-10 py-12 text-left">
        <header className="mb-12 flex flex-col lg:flex-row justify-between items-start lg:items-end gap-10 text-left">
          <div className="text-left">
            <div className="inline-flex items-center gap-3 bg-emerald-50 text-emerald-700 px-5 py-2 rounded-full text-[11px] font-black uppercase tracking-widest mb-6 border border-emerald-100/50 shadow-sm"><span className="w-2.5 h-2.5 rounded-full bg-emerald-600 animate-pulse" /> Patient Privacy Level: High</div>
            <h1 className="text-7xl font-black text-slate-900 tracking-tight leading-none mb-4 text-left">Resilience <span className="text-indigo-600">Sync</span></h1>
            <p className="text-slate-400 font-medium text-lg text-left">Student Identifier: {user?.id} • {new Date().toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric'})}</p>
          </div>
          <div className="flex gap-5 w-full lg:w-auto">
            <button onClick={async () => setToken(await API.createToken(user!.id))} className="flex-1 lg:flex-none bg-white border-2 border-slate-100 px-10 py-5 rounded-[2rem] font-black text-slate-800 hover:bg-slate-50 hover:border-indigo-100 transition-all shadow-sm">Authorize Review</button>
            <button onClick={() => setView('checkin')} className="flex-1 lg:flex-none bg-indigo-600 text-white px-12 py-5 rounded-[2rem] font-black shadow-2xl shadow-indigo-200 hover:bg-indigo-700 hover:shadow-indigo-300 transition-all transform hover:-translate-y-1">Record Entry</button>
          </div>
        </header>

        {token && (
          <div className="mb-12 p-10 bg-gradient-to-br from-indigo-700 via-indigo-800 to-indigo-950 text-white rounded-[3rem] shadow-2xl flex flex-col md:flex-row items-center justify-between animate-in zoom-in duration-500 relative overflow-hidden group text-left">
            <div className="absolute top-0 right-0 w-64 h-64 bg-white/5 blur-[80px] rounded-full translate-x-1/2 -translate-y-1/2 group-hover:scale-125 transition-transform duration-700" />
            <div className="relative z-10 mb-6 md:mb-0 text-center md:text-left text-left"><p className="text-[11px] font-black uppercase tracking-[0.3em] opacity-60 mb-3 text-left">Clinical Access Key</p><h3 className="text-5xl font-mono font-black tracking-[0.25em] text-left">{token}</h3></div>
            <div className="relative z-10 text-center md:text-right text-right"><p className="text-sm font-bold opacity-80 mb-6 max-w-[280px] text-right">Provide this key for non-diagnostic trend visualization.</p><button onClick={() => setToken(null)} className="bg-white/10 hover:bg-white/20 px-8 py-3 rounded-2xl font-black text-[10px] uppercase tracking-widest transition-all">Revoke</button></div>
          </div>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 mb-16 items-stretch text-left">
            <div className="bg-white p-10 rounded-[3rem] border border-slate-100 shadow-sm flex flex-col justify-center text-left animate-in fade-in slide-in-from-left-8 duration-700 text-left">
              <h2 className="text-5xl font-black text-slate-900 tracking-tighter mb-4 leading-none text-left">Welcome back,<br/><span className="text-indigo-600">{user?.id}</span></h2>
              <p className="text-xl text-slate-400 font-bold uppercase tracking-widest text-left">Start your journey by checking in today.</p>
            </div>
            
            <div className="bg-[#FFB703] text-black rounded-[3.5rem] p-10 flex flex-col sm:flex-row items-center gap-10 border-[6px] border-black shadow-[12px_12px_0px_0px_rgba(0,0,0,1)] transition-all hover:translate-x-[4px] hover:translate-y-[4px] hover:shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] active:translate-x-[12px] active:translate-y-[12px] active:shadow-none cursor-pointer relative overflow-hidden text-left">
              <div className="w-20 h-20 bg-white border-4 border-black rounded-full flex items-center justify-center shrink-0 shadow-[6px_6px_0px_0px_rgba(0,0,0,1)] animate-bounce">
                <span className="text-4xl">⭐</span>
              </div>
              <div className="flex-1 text-center sm:text-left text-left">
                <h4 className="text-[14px] font-black uppercase tracking-[0.2em] mb-2 bg-black text-white px-3 py-1 inline-block rounded-lg text-left">Super Support!</h4>
                <p className="text-3xl font-black tracking-tighter leading-tight mb-3 text-left">Feeling overwhelmed? Help is just a tap away!</p>
                <div className="flex items-center justify-center sm:justify-start gap-4 text-left">
                    <span className="text-5xl font-black tracking-tighter text-left">Dial 988</span>
                    <div className="bg-white border-4 border-black px-4 py-1 rounded-2xl font-black text-xs uppercase tracking-widest shadow-[4px_4px_0px_0px_rgba(0,0,0,1)]">Crisis Hotline</div>
                </div>
              </div>
            </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 text-left items-start">
          <div className="lg:col-span-8 space-y-12 text-left">
            <GlassCard title="Wellness Trajectory" subtitle="Longitudinal Mapping Protocol">
              <div className="h-[450px] w-full pt-4">
                {chartData.length > 0 ? (
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart 
                      data={chartData}
                      margin={{ top: 20, right: 30, left: 10, bottom: 20 }}
                    >
                      <defs><linearGradient id="proGradient" x1="0" y1="0" x2="0" y2="1"><stop offset="5%" stopColor="#4f46e5" stopOpacity={0.2}/><stop offset="95%" stopColor="#4f46e5" stopOpacity={0}/></linearGradient></defs>
                      <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
                      <XAxis dataKey="date" fontSize={11} fontWeight={800} stroke="#cbd5e1" axisLine={false} tickLine={false} tickMargin={12} />
                      <YAxis domain={[0, 100]} fontSize={11} fontWeight={800} stroke="#cbd5e1" axisLine={false} tickLine={false} tickMargin={12} />
                      <Tooltip contentStyle={{ borderRadius: '24px', border: 'none', boxShadow: '0 30px 60px -15px rgb(0 0 0 / 0.15)', padding: '20px' }} />
                      <Area type="monotone" dataKey="score" stroke="#4f46e5" strokeWidth={8} fillOpacity={1} fill="url(#proGradient)" dot={{ r: 8, fill: '#4f46e5', strokeWidth: 4, stroke: '#fff' }} activeDot={{ r: 12, strokeWidth: 0 }} animationDuration={1500} isAnimationActive={true} />
                    </AreaChart>
                  </ResponsiveContainer>
                ) : <div className="h-full flex items-center justify-center font-black text-slate-200 text-2xl uppercase tracking-tighter opacity-50">Awaiting Vault Sync</div>}
              </div>
            </GlassCard>
            
            <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-left">
              <StatMetric label="Sleep" value={`${lastEntry?.sleepHours || 0}h`} sub="Daily" color="text-indigo-600" icon={<Icons.Sleep />} />
              <StatMetric label="Vitality" value={`${lastEntry?.energyLevel || 0}/10`} sub="Reserve" color="text-emerald-500" icon={<Icons.Energy />} />
              <StatMetric label="Anxiety" value={`${lastEntry?.anxietyLevel || 0}/10`} sub="Index" color="text-rose-500" icon={<Icons.Anxiety />} />
              <StatMetric label="Social" value={lastEntry?.socialConnection || '-'} sub="Vibe" color="text-amber-500" icon={<Icons.Social />} />
            </div>

            {/* NEW: CLINICAL DIRECTIVES SECTION (WHERE PRESCRIPTIONS LIVE) */}
            <GlassCard title="Practitioner Response" subtitle="Synced Directives & Clinical Notes" accent="emerald">
                <div className="space-y-6 text-left">
                    {feedback.slice().reverse().map((f, idx) => (
                        <div key={f.id} className="p-8 bg-emerald-50/50 rounded-3xl border border-emerald-100/50 flex flex-col gap-6 text-left transition-all hover:bg-white hover:shadow-xl group">
                            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 text-left">
                                <div className="text-left">
                                    <h4 className="text-xl font-black text-slate-900 tracking-tight text-left">
                                        Note from {f.counselorName}, <span className="text-indigo-600">{f.reviewerTitle}</span>
                                    </h4>
                                    <p className="text-[10px] font-black uppercase text-slate-400 tracking-widest text-left">
                                        {f.reviewerSpecialty} • {f.reviewerDepartment}
                                    </p>
                                </div>
                                <div className="text-right text-[10px] font-black text-slate-400 uppercase tracking-widest text-right">
                                    {new Date(f.timestamp).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}
                                </div>
                            </div>
                            <div className="p-6 bg-white rounded-2xl border border-emerald-100 text-left">
                                <p className="text-slate-700 font-medium leading-relaxed italic text-left">"{f.content}"</p>
                            </div>
                            {f.interventions && f.interventions.length > 0 && (
                                <div className="flex flex-wrap gap-2 text-left">
                                    {f.interventions.map((int, i) => (
                                        <span key={i} className="px-4 py-1.5 bg-emerald-600 text-white rounded-full text-[9px] font-black uppercase tracking-widest shadow-md">
                                            {int}
                                        </span>
                                    ))}
                                </div>
                            )}
                        </div>
                    ))}
                    {feedback.length === 0 && (
                        <div className="py-20 text-center text-slate-300 font-bold italic text-left">
                            No clinical directives synced to your vault yet.
                        </div>
                    )}
                </div>
            </GlassCard>

            <GlassCard title="Vault Journal History" subtitle="Your private, encrypted daily reflections">
                <div className="space-y-6 text-left">
                    {entries.slice().reverse().map((e, idx) => (
                        <div key={e.id} className="p-8 bg-slate-50/50 rounded-3xl border border-slate-100 flex flex-col md:flex-row gap-8 transition-all hover:bg-white hover:shadow-md group text-left">
                            <div className="md:w-32 shrink-0 text-left">
                                <p className="text-[10px] font-black uppercase text-indigo-400 tracking-widest mb-1 text-left">{new Date(e.timestamp).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}</p>
                                <div className={`inline-block px-3 py-1 rounded-full text-[9px] font-black uppercase tracking-widest text-left ${e.riskLevel === 'High' ? 'bg-rose-100 text-rose-600' : 'bg-emerald-100 text-emerald-600'}`}>
                                    {e.riskLevel}
                                </div>
                            </div>
                            <div className="flex-1 text-left">
                                {e.reflection ? (
                                    <p className="text-slate-700 font-medium leading-relaxed italic text-left">"{e.reflection}"</p>
                                ) : (
                                    <p className="text-slate-300 font-bold italic text-sm text-left">No reflection provided for this session.</p>
                                )}
                            </div>
                        </div>
                    ))}
                </div>
            </GlassCard>
          </div>

          <div className="lg:col-span-4 space-y-12 h-fit text-left">
            <GlassCard title="Clinical Consult" subtitle="Direct Inquiry Channel" accent="indigo">
              <div className="space-y-6 text-left">
                <textarea value={newQuestion} onChange={e => setNewQuestion(e.target.value)} placeholder="Inquiry..." className="w-full bg-slate-50 border-2 border-slate-100 p-6 rounded-[2rem] outline-none transition-all focus:border-indigo-500 focus:bg-white font-medium text-sm text-slate-700 min-h-[140px] resize-none shadow-inner text-left" />
                <button onClick={submitQuestion} disabled={!newQuestion.trim()} className="w-full bg-indigo-600 hover:bg-indigo-700 disabled:opacity-40 text-white font-black py-5 rounded-[2rem] shadow-xl shadow-indigo-100 transition-all uppercase tracking-widest text-xs">Send</button>
              </div>
            </GlassCard>

            <div className="bg-slate-900 rounded-[3rem] p-12 text-white shadow-2xl relative overflow-hidden group border border-slate-800 text-left">
              <div className="absolute top-0 right-0 w-48 h-48 bg-indigo-500/10 blur-[100px] rounded-full translate-x-12 -translate-y-12 group-hover:scale-150 transition-all duration-1000" />
              <div className="relative z-10 text-left">
                <div className="flex items-center gap-4 mb-10 text-left"><div className="w-10 h-10 bg-indigo-600 rounded-xl flex items-center justify-center shadow-lg"><Icons.Intelligence /></div><span className="text-[11px] font-black uppercase tracking-[0.3em] text-indigo-400 text-left">Daily Insight Brief</span></div>
                <h4 className="text-3xl font-black mb-8 tracking-tight leading-none text-left">Your Companion Support</h4>
                {isAiLoading ? (<div className="space-y-6 text-left"><div className="h-4 bg-white/5 rounded-full w-full animate-pulse" /><div className="h-4 bg-white/5 rounded-full w-3/4 animate-pulse" /><div className="h-4 bg-white/5 rounded-full w-full animate-pulse" /></div>) : (
                  <div className="space-y-8 text-left">
                    {aiAdvice.map((a, i) => <div key={i} className="flex gap-4 items-start border-l-4 border-indigo-500 pl-6 py-2 transition-all hover:bg-white/5 rounded-r-2xl text-left"><p className="text-base font-medium leading-relaxed opacity-95 text-slate-200 text-left">{a.trim()}</p></div>)}
                  </div>
                )}
                <button onClick={() => fetchAiInsights(entries)} className="mt-10 w-full py-5 bg-indigo-600 rounded-[2rem] font-black text-[12px] uppercase tracking-[0.2em] hover:bg-indigo-500 transition-all shadow-xl shadow-indigo-600/20">Refresh Advice</button>
              </div>
            </div>

            <GlassCard title="Security Index" subtitle="Encrypted Analysis">
              <div className="text-center py-6 text-center">
                <div className={`w-36 h-36 mx-auto rounded-[3.5rem] flex items-center justify-center text-6xl shadow-[0_40px_80px_-20px_rgba(0,0,0,0.1)] mb-8 transform transition-all hover:rotate-12 ${lastEntry?.riskLevel === 'High' ? 'bg-rose-500 text-white' : lastEntry?.riskLevel === 'Moderate' ? 'bg-amber-500 text-white' : 'bg-emerald-500 text-white'}`}>{lastEntry?.riskScore > 70 ? '🆘' : lastEntry?.riskScore > 40 ? '⚠️' : '🛡️'}</div>
                <h3 className="text-4xl font-black text-slate-900 tracking-tighter mb-2 text-center">{lastEntry?.riskLevel || 'Nominal'}</h3>
                <p className="text-[11px] font-black uppercase text-slate-400 tracking-[0.25em] text-center">{lastEntry?.riskScore || 0}% Score</p>
              </div>
            </GlassCard>
          </div>
        </div>
      </main>
    </div>
  );

  const renderCheckIn = () => (
    <div className="min-h-screen bg-[#FDFDFF] py-20 px-8 flex items-center justify-center text-left">
      <div className="w-full max-w-4xl animate-in fade-in slide-in-from-bottom-12 duration-700 text-left">
        <button onClick={() => setView('dashboard')} className="mb-12 flex items-center gap-4 text-slate-400 hover:text-indigo-600 transition-all font-black text-[11px] uppercase tracking-widest text-left"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-6 h-6"><path fillRule="evenodd" d="M11.03 3.97a.75.75 0 0 1 0 1.06l-6.22 6.22H21a.75.75 0 0 1 0 1.5H4.81l6.22 6.22a.75.75 0 1 1-1.06 1.06l-7.5-7.5a.75.75 0 0 1 0-1.06l7.5-7.5a.75.75 0 0 1 1.06 0Z" clipRule="evenodd" /></svg>Discard</button>
        <div className="bg-white rounded-[4rem] p-20 shadow-[0_60px_120px_-30px_rgba(0,0,0,0.08)] border border-slate-100 text-left">
          <form onSubmit={async (e) => { e.preventDefault(); const d = new FormData(e.currentTarget); handleCheckIn({ mood: Number(d.get('mood')), stress: d.get('stress'), sleepHours: Number(d.get('sleep')), anxietyLevel: Number(d.get('anxiety')), energyLevel: Number(d.get('energy')), socialConnection: d.get('social'), reflection: checkInReflection }); }} className="space-y-16 text-left">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-16 text-left">
              <div className="space-y-8 text-left"><label className="block text-[11px] font-black uppercase text-slate-400 tracking-widest text-left text-left">Mood</label><div className="flex justify-between gap-3 text-left">{[1, 2, 3, 4, 5].map(m => (<label key={m} className="flex-1 cursor-pointer group text-left"><input type="radio" name="mood" value={m} className="peer hidden text-left" defaultChecked={m === 3} /><div className="py-8 bg-slate-50/50 rounded-[2rem] border-2 border-slate-100 text-3xl text-center grayscale peer-checked:grayscale-0 peer-checked:border-indigo-600 peer-checked:bg-white transition-all transform hover:scale-105 peer-checked:scale-110 text-center">{m === 1 ? '😔' : m === 2 ? '😕' : m === 3 ? '😐' : m === 4 ? '🙂' : '😊'}</div></label>))}</div></div>
              <div className="space-y-8 text-left"><label className="block text-[11px] font-black uppercase text-slate-400 tracking-widest text-left text-left">Stress</label><select name="stress" className="w-full bg-slate-50/50 border-2 border-slate-100 p-6 rounded-[2rem] outline-none focus:border-indigo-600 font-black text-lg appearance-none text-left"><option value="low">Low</option><option value="medium">Medium</option><option value="high">High</option></select></div>
              <div className="space-y-8 text-left text-left"><label className="block text-[11px] font-black uppercase text-rose-500 tracking-widest text-left text-left">Anxiety Index (1-10)</label><input name="anxiety" type="range" min="1" max="10" step="1" className="w-full h-3 bg-slate-100 rounded-full appearance-none accent-rose-500 cursor-pointer text-left" defaultValue="5" /></div>
              <div className="space-y-8 text-left text-left"><label className="block text-[11px] font-black uppercase text-emerald-500 tracking-widest text-left text-left">Energy Index (1-10)</label><input name="energy" type="range" min="1" max="10" step="1" className="w-full h-3 bg-slate-100 rounded-full appearance-none accent-emerald-500 cursor-pointer text-left" defaultValue="5" /></div>
            </div>
            <div className="space-y-8 text-left text-left"><label className="block text-[11px] font-black uppercase text-slate-400 tracking-widest text-left text-left text-left">Daily Note (Written Reflection)</label><textarea value={checkInReflection} onChange={e => setCheckInReflection(e.target.value)} className="w-full bg-slate-50/50 border-2 border-slate-100 p-8 rounded-[2.5rem] outline-none focus:border-indigo-600 font-medium text-lg min-h-[180px] text-slate-700 resize-none transition-all focus:bg-white focus:ring-4 focus:ring-indigo-50 shadow-inner text-left" placeholder="Notes..." /></div>
            <button type="submit" className="w-full bg-indigo-600 text-white font-black py-8 rounded-[3rem] shadow-3xl shadow-indigo-100 hover:bg-indigo-700 transition-all text-2xl tracking-tighter text-center">Synchronize Vault Record</button>
          </form>
        </div>
      </div>
    </div>
  );

  const renderCounselor = () => (
    <div className="min-h-screen bg-[#070912] flex flex-col items-center p-10 relative overflow-x-hidden text-left font-sans">
      <div className="absolute top-0 left-0 w-full h-screen bg-gradient-to-b from-indigo-500/5 via-transparent to-indigo-900/5 pointer-events-none text-left" />
      <nav className="w-full max-w-7xl flex justify-between items-center mb-16 relative z-10 text-left">
        <button onClick={() => { setCounselorData(null); setView('landing'); }} className="group flex items-center gap-3 text-white/50 hover:text-white transition-all font-black text-xs uppercase tracking-widest text-left text-left">
            <div className="w-8 h-8 rounded-lg bg-white/5 border border-white/10 flex items-center justify-center group-hover:bg-white/10 text-center">&larr;</div>
            Exit Terminal
        </button>
        <div className="flex gap-4 text-left">
            <button onClick={() => setIsEditingProfile(true)} className="flex items-center gap-4 bg-white/5 px-6 py-2 rounded-2xl border border-white/10 backdrop-blur-md text-white/60 hover:text-white hover:bg-white/10 transition-all text-left">
                <span className="text-[10px] font-black uppercase tracking-widest text-left">Profile Sync</span>
            </button>
            <div className="flex items-center gap-4 bg-white/5 px-6 py-2 rounded-2xl border border-white/10 backdrop-blur-md text-left">
                <div className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse text-left" />
                <span className="text-[10px] font-black text-white/80 uppercase tracking-widest text-left">Secure Uplink: Stable</span>
            </div>
        </div>
      </nav>

      {isEditingProfile && (
          <div className="fixed inset-0 z-[100] bg-slate-950/90 backdrop-blur-md flex items-center justify-center p-8 text-left">
              <div className="w-full max-w-xl bg-white p-12 rounded-[4rem] shadow-3xl animate-in zoom-in duration-300 text-left">
                  <h3 className="text-3xl font-black text-slate-900 mb-8 tracking-tighter text-left">Practitioner Profile Sync</h3>
                  <div className="space-y-6 mb-10 text-left">
                    <div className="space-y-2 text-left"><label className="text-[10px] font-black uppercase text-slate-400 tracking-widest ml-2 text-left text-left">Full Legal Name</label><input value={doctorName} onChange={e => setDoctorName(e.target.value)} className="w-full bg-slate-50 border-2 border-slate-100 p-5 rounded-3xl font-bold text-left" /></div>
                    <div className="space-y-2 text-left"><label className="text-[10px] font-black uppercase text-slate-400 tracking-widest ml-2 text-left text-left">Professional Title</label><input value={doctorTitle} onChange={e => setDoctorTitle(e.target.value)} className="w-full bg-slate-50 border-2 border-slate-100 p-5 rounded-3xl font-bold text-left" /></div>
                    <div className="space-y-2 text-left"><label className="text-[10px] font-black uppercase text-slate-400 tracking-widest ml-2 text-left text-left">Clinical Specialty</label><input value={doctorSpecialty} onChange={e => setDoctorSpecialty(e.target.value)} className="w-full bg-slate-50 border-2 border-slate-100 p-5 rounded-3xl font-bold text-left" /></div>
                    <div className="space-y-2 text-left"><label className="text-[10px] font-black uppercase text-slate-400 tracking-widest ml-2 text-left text-left">Department</label><input value={doctorDepartment} onChange={e => setDoctorDepartment(e.target.value)} className="w-full bg-slate-50 border-2 border-slate-100 p-5 rounded-3xl font-bold text-left" /></div>
                  </div>
                  <button onClick={() => setIsEditingProfile(false)} className="w-full bg-indigo-600 text-white py-6 rounded-[2rem] font-black uppercase tracking-widest text-xs shadow-xl shadow-indigo-100 text-center">Synchronize Signature</button>
              </div>
          </div>
      )}

      {!counselorData ? (
        <div className="w-full max-w-xl bg-white p-20 rounded-[4rem] shadow-3xl animate-in zoom-in duration-500 relative z-10 text-center text-center">
          <h2 className="text-5xl font-black text-slate-900 mb-4 tracking-tighter leading-none text-center">Practitioner Auth</h2>
          <p className="text-slate-400 font-black text-xs uppercase tracking-[0.4em] mb-16 text-center text-center">Enter Vault Access Key</p>
          <div className="space-y-8 text-center">
            <input value={searchToken} onChange={e => setSearchToken(e.target.value.toUpperCase())} placeholder="SESSION-KEY" className="w-full bg-slate-50 border-4 border-slate-100 p-8 rounded-[2.5rem] text-center text-4xl font-mono font-black mb-10 outline-none focus:border-indigo-500 uppercase tracking-widest text-indigo-950 shadow-inner text-center" />
            <button onClick={() => API.getCounselorView(searchToken).then(data => { setCounselorData(data); fetchCounselorSummary(data); }).catch(() => alert("Denied"))} className="w-full bg-indigo-600 text-white py-8 rounded-[2.5rem] font-black text-2xl uppercase tracking-widest shadow-2xl shadow-indigo-600/20 hover:bg-indigo-700 transition-all text-center">Establish Session</button>
          </div>
        </div>
      ) : (
        <div className="w-full max-w-7xl animate-in fade-in slide-in-from-bottom-10 duration-700 relative z-10 grid grid-cols-1 lg:grid-cols-12 gap-10 text-left text-left">
          
          <div className="lg:col-span-12 relative text-left text-left">
            <div className="absolute top-0 left-0 w-80 h-10 bg-slate-900/60 backdrop-blur-xl border-t border-l border-r border-white/10 rounded-t-[2rem] flex items-center px-10 text-left">
                <span className="text-[9px] font-black text-indigo-400 uppercase tracking-[0.3em] text-left">SECURE CLINICAL TERMINAL</span>
            </div>
            <div className="mt-10 flex flex-col md:flex-row justify-between items-start md:items-center gap-10 bg-slate-900/40 p-12 rounded-[3.5rem] rounded-tl-none border border-white/10 backdrop-blur-2xl shadow-[0_40px_100px_-20px_rgba(0,0,0,0.5)] text-left">
              <div className="flex items-center gap-10 text-left">
                  <div className="relative text-left">
                    <div className="w-24 h-24 bg-gradient-to-br from-indigo-500 to-indigo-700 rounded-[2.5rem] flex items-center justify-center font-black text-4xl text-white shadow-2xl shadow-indigo-500/30 transform transition-all hover:scale-105 active:scale-95 cursor-pointer text-center">
                        {doctorName.split(' ').map(n => n[0]).join('')}
                    </div>
                    <div className="absolute -bottom-2 -right-2 w-8 h-8 bg-emerald-500 rounded-full border-4 border-slate-900 flex items-center justify-center text-center">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="white" className="w-4 h-4"><path fillRule="evenodd" d="M16.704 4.153a.75.75 0 0 1 .143 1.052l-8 10.5a.75.75 0 0 1-1.127.075l-4.5-4.5a.75.75 0 0 1 1.06-1.06l3.894 3.893 7.48-9.817a.75.75 0 0 1 1.05-.143Z" clipRule="evenodd" /></svg>
                    </div>
                  </div>
                  <div className="text-left text-left">
                      <h2 className="text-4xl font-black text-white tracking-tighter leading-none mb-3 text-left">
                          {doctorName}, <span className="text-indigo-400 opacity-80">{doctorTitle}</span>
                      </h2>
                      <p className="text-[11px] font-black uppercase text-white/40 tracking-[0.3em] mb-4 text-left">
                          {doctorSpecialty} <span className="mx-2 opacity-30">•</span> {doctorDepartment}
                      </p>
                      <div className="inline-flex items-center gap-3 bg-indigo-500/10 border border-indigo-500/20 px-4 py-2 rounded-2xl shadow-inner text-left">
                          <span className="w-2 h-2 rounded-full bg-indigo-500 shadow-[0_0_12px_rgba(99,102,241,1)]" />
                          <span className="text-[10px] font-black text-indigo-300 uppercase tracking-widest text-left">Digital MD Signature Verified</span>
                      </div>
                  </div>
              </div>
              <div className="flex flex-col items-end gap-3 text-right text-right">
                  <p className="text-[11px] font-black text-white/20 uppercase tracking-[0.4em] text-right">Reviewing Identity</p>
                  <div className="text-5xl font-black text-white tracking-tighter leading-none font-mono text-right">{counselorData.ownerId}</div>
                  <div className={`px-6 py-2 rounded-2xl text-[10px] font-black uppercase tracking-[0.25em] mt-3 border shadow-2xl text-right ${counselorData.currentRiskLevel === 'High' ? 'bg-rose-500/20 border-rose-500/40 text-rose-500' : 'bg-emerald-500/20 border-emerald-500/40 text-emerald-500'}`}>
                      {counselorData.currentRiskLevel} RISK THRESHOLD
                  </div>
              </div>
            </div>
          </div>

          <div className="lg:col-span-8 space-y-10 text-left">
            <div className="bg-slate-900/30 backdrop-blur-3xl p-12 rounded-[4rem] border border-white/5 shadow-3xl text-left text-left">
                <div className="flex justify-between items-center mb-12 text-left">
                    <div className="text-left text-left">
                        <h3 className="text-2xl font-black text-white tracking-tight leading-none mb-2 text-left text-left">Clinical Trend Engine</h3>
                        <p className="text-[10px] font-bold text-white/30 uppercase tracking-[0.2em] text-left text-left">Predictive Risk Index Sync</p>
                    </div>
                    <div className="flex gap-12 text-right text-right">
                        <div className="text-right text-right">
                            <p className="text-5xl font-black text-indigo-400 tracking-tighter leading-none mb-1 text-right">{counselorData.entriesCount}</p>
                            <p className="text-[10px] font-black text-white/20 uppercase tracking-widest text-right text-right">Sync Logs</p>
                        </div>
                    </div>
                </div>
                <div className="h-[360px] text-left">
                    <ResponsiveContainer width="100%" height="100%">
                        <BarChart data={counselorData.riskTrend} margin={{ top: 10, right: 30, left: 10, bottom: 10 }}>
                            <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#ffffff05" />
                            <XAxis dataKey="timestamp" hide />
                            <YAxis domain={[0, 100]} hide />
                            <Tooltip 
                                contentStyle={{ backgroundColor: '#0f172a', border: '1px solid #1e293b', borderRadius: '16px', color: '#fff', textAlign: 'left' }}
                                cursor={{ fill: '#ffffff05', radius: 12 }} 
                            />
                            <Bar dataKey="score" radius={[10, 10, 10, 10]}>
                                {counselorData.riskTrend.map((entry: any, index: number) => (
                                    <Cell key={`cell-${index}`} fill={entry.score > 70 ? '#f43f5e' : entry.score > 40 ? '#f59e0b' : '#6366f1'} />
                                ))}
                            </Bar>
                        </BarChart>
                    </ResponsiveContainer>
                </div>
            </div>

            <div className="bg-white/5 backdrop-blur-md p-10 rounded-[4rem] border border-white/10 text-left text-left">
                <div className="flex items-center justify-between mb-10 text-left">
                    <h3 className="text-xl font-black text-white tracking-tight flex items-center gap-4 text-left text-left text-left">
                        <span className="w-2.5 h-2.5 rounded-full bg-indigo-500 shadow-[0_0_12px_rgba(99,102,241,1)]" />
                        Patient Direct Inquiry
                    </h3>
                    <span className="text-[11px] font-black text-indigo-300 bg-indigo-500/10 px-5 py-2 rounded-full uppercase tracking-widest text-left">{counselorData.pendingQuestions.length} UNRESOLVED</span>
                </div>
                <div className="space-y-4 text-left">
                    {counselorData.pendingQuestions.length > 0 ? counselorData.pendingQuestions.map((q: any) => (
                        <button 
                            key={q.id} 
                            onClick={() => { setActiveQuestionId(q.id); setDoctorNote(prev => prev ? prev + "\n\nRESPONSE TO QUERY [" + q.id + "]: " + q.content : "In addressing your specific concern: " + q.content); }}
                            className={`w-full text-left p-10 rounded-[3rem] border-2 transition-all flex justify-between items-center group text-left ${activeQuestionId === q.id ? 'bg-indigo-600/30 border-indigo-500 shadow-3xl transform -translate-y-1' : 'bg-white/5 border-white/5 hover:border-white/10'}`}
                        >
                            <div className="text-left text-left">
                                <p className="text-[10px] font-black uppercase text-indigo-400 mb-3 text-left text-left">CRYPTO-QUEUE-ID {q.id}</p>
                                <p className="text-white font-medium text-lg leading-relaxed text-left text-left text-left">"{q.content}"</p>
                            </div>
                            <div className={`w-14 h-14 rounded-3xl border flex items-center justify-center transition-all shrink-0 ml-10 text-center ${activeQuestionId === q.id ? 'bg-white border-transparent' : 'border-white/10 opacity-30 group-hover:opacity-100'}`}>
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill={activeQuestionId === q.id ? "#4f46e5" : "white"} className="w-8 h-8"><path fillRule="evenodd" d="M10 18a8 8 0 1 0 0-16 8 8 0 0 0 0 16Zm.75-11.25a.75.75 0 0 0-1.5 0v2.5h-2.5a.75.75 0 0 0 0 1.5h2.5v2.5a.75.75 0 0 0 1.5 0v-2.5h2.5a.75.75 0 0 0 0-1.5h-2.5v-2.5Z" clipRule="evenodd" /></svg>
                            </div>
                        </button>
                    )) : (
                        <div className="p-20 border-2 border-dashed border-white/5 rounded-[4rem] text-center text-white/20 font-black italic text-center">No pending clinical inquiries from patient.</div>
                    )}
                </div>
            </div>
          </div>

          <div className="lg:col-span-4 space-y-10 text-left">
            <div className="bg-gradient-to-br from-indigo-800 to-indigo-950 p-12 rounded-[4rem] shadow-3xl text-white relative overflow-hidden group border border-white/10 text-left text-left">
                <div className="absolute top-0 right-0 w-48 h-48 bg-white/5 blur-[80px] rounded-full translate-x-1/2 -translate-y-1/2 text-left" />
                <div className="relative z-10 text-left text-left text-left">
                    <div className="flex items-center gap-5 mb-10 text-left text-left">
                        <div className="w-12 h-12 bg-white/10 rounded-2xl flex items-center justify-center shadow-inner animate-pulse text-center"><Icons.Intelligence /></div>
                        <span className="text-[11px] font-black uppercase tracking-[0.4em] text-white/60 text-left text-left">Intelligence Brief</span>
                    </div>
                    <h3 className="text-3xl font-black mb-8 tracking-tight leading-none text-left text-left">Patient Abstract</h3>
                    {isCounselorAiLoading ? (
                        <div className="space-y-5 text-left text-left">
                            <div className="h-4 bg-white/20 rounded-full w-full animate-pulse text-left" />
                            <div className="h-4 bg-white/20 rounded-full w-3/4 animate-pulse text-left" />
                        </div>
                    ) : (
                        <p className="text-base font-medium leading-relaxed italic border-l-[6px] border-indigo-500/50 pl-8 text-left text-left text-left">{counselorAiSummary}</p>
                    )}
                </div>
            </div>

            <div className="bg-white p-12 rounded-[4rem] shadow-3xl text-slate-900 border border-slate-100 flex flex-col h-fit text-left text-left">
              <div className="flex justify-between items-center mb-10 text-left text-left">
                  <h3 className="text-3xl font-black tracking-tighter text-left text-left leading-none mb-1 text-left">Session Decisions</h3>
                  <div className="text-[10px] font-black uppercase text-slate-400 bg-slate-50 px-4 py-2 rounded-xl border border-slate-100 tracking-widest text-left text-left">ACTIVE SESSION</div>
              </div>
              
              <div className="space-y-10 mb-10 text-left text-left">
                <div className="space-y-5 text-left text-left">
                    <label className="block text-[11px] font-black uppercase text-indigo-600 tracking-widest ml-3 text-left text-left text-left">Clinical Protocol Hierarchy</label>
                    <div className="grid grid-cols-2 gap-4 text-left text-left">
                        {['Behavioral Reset', 'Sleep Hygiene', 'Crisis Plan', 'Medication Adj'].map(int => (
                            <button 
                                key={int} 
                                onClick={() => setDoctorInterventions(prev => prev.includes(int) ? prev.filter(i => i !== int) : [...prev, int])} 
                                className={`p-6 rounded-3xl border-2 text-left font-black text-[11px] uppercase tracking-wider transition-all flex flex-col justify-between h-28 text-left ${doctorInterventions.includes(int) ? 'bg-indigo-600 border-indigo-500 text-white shadow-2xl' : 'bg-slate-50 border-slate-100 hover:border-indigo-400 text-slate-400'}`}
                            >
                                {int}
                                <div className={`w-8 h-8 rounded-2xl flex items-center justify-center border-2 transition-all text-center ${doctorInterventions.includes(int) ? 'bg-white text-indigo-600 border-transparent shadow-lg' : 'border-slate-200'}`}>
                                    {doctorInterventions.includes(int) && <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" className="w-5 h-5"><path fillRule="evenodd" d="M16.704 4.153a.75.75 0 0 1 .143 1.052l-8 10.5a.75.75 0 0 1-1.127.075l-4.5-4.5a.75.75 0 0 1 1.06-1.06l3.894 3.893 7.48-9.817a.75.75 0 0 1 1.05-.143Z" clipRule="evenodd" /></svg>}
                                </div>
                            </button>
                        ))}
                    </div>
                </div>

                <div className="space-y-5 text-left text-left">
                    <label className="block text-[11px] font-black uppercase text-indigo-600 tracking-widest ml-3 text-left text-left text-left">Clinical Rationale (Encrypted Signature)</label>
                    <textarea 
                        value={doctorNote} 
                        onChange={e => setDoctorNote(e.target.value)} 
                        placeholder="Commit clinical observations to the patient vault..." 
                        className="w-full bg-slate-50 border-2 border-slate-100 p-8 rounded-[2.5rem] outline-none focus:border-indigo-400 font-medium text-base text-slate-700 min-h-[180px] resize-none shadow-inner transition-all focus:bg-white text-left text-left text-left" 
                    />
                </div>
              </div>
              <button 
                onClick={submitClinicalNote} 
                className="w-full bg-slate-950 hover:bg-black text-white py-8 rounded-[3rem] font-black uppercase tracking-[0.25em] transition-all shadow-3xl text-xs active:scale-[0.98] flex items-center justify-center gap-4 text-left text-left px-12"
              >
                COMMIT SYNC & CLOSE REVIEW
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" className="w-5 h-5"><path fillRule="evenodd" d="M10 1a.75.75 0 0 1 .75.75v4.637c1.13.177 2.1.885 2.68 1.907a.75.75 0 1 1-1.307.733.75.75 0 0 0-1.373-.327V11a.75.75 0 0 1-1.5 0V8.703a.75.75 0 0 0-1.373.327.75.75 0 1 1-1.307-.733c.58-1.022 1.55-1.73 2.68-1.907V1.75A.75.75 0 0 1 10 1ZM4.994 14.235A8 8 0 1 1 15 14.235c.18.18.22.43.126.607l-1.568 2.973a.75.75 0 0 1-1.315-.72l1.32-2.503a6.5 6.5 0 1 0-7.126 0l1.32 2.503a.75.75 0 0 1-1.315.72l-1.568-2.973a.375.375 0 0 1 .126-.607Z" clipRule="evenodd" /></svg>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );

  // --- Main Dispatcher ---

  switch (view) {
    case 'landing': return renderLanding();
    case 'dashboard': return renderDashboard();
    case 'checkin': return renderCheckIn();
    case 'counselor': return renderCounselor();
    case 'login': return (
      <div className="min-h-screen flex items-center justify-center p-8 bg-[#F8FAFC] text-center text-center">
        <div className="w-full max-lg bg-white/80 backdrop-blur-3xl p-16 rounded-[4rem] shadow-2xl border border-white/50 relative z-10 text-center text-center animate-in zoom-in duration-700">
          <div className="w-28 h-28 bg-gradient-to-br from-indigo-600 to-indigo-900 rounded-[3rem] mx-auto mb-10 shadow-3xl flex items-center justify-center text-white ring-[16px] ring-indigo-50 text-center"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-14 h-14"><path fillRule="evenodd" d="M12 1.5a5.25 5.25 0 0 0-5.25 5.25v3a3 3 0 0 0-3 3v6.75a3 3 0 0 0 3 3h10.5a3 3 0 0 0 3-3v-6.75a3 3 0 0 0-3-3v-3A5.25 5.25 0 0 0 12 1.5Zm-3.75 8.25v-3a3.75 3.75 0 1 1 7.5 0v3H8.25Z" clipRule="evenodd" /></svg></div>
          <h1 className="text-5xl font-black text-slate-900 mb-14 tracking-tighter text-center text-center text-center">MindSafe <span className="text-indigo-600 font-light italic">Vault</span></h1>
          <form onSubmit={handleLogin} className="space-y-8 text-left text-left">
            <div className="text-left"><label className="block text-[10px] font-black uppercase tracking-widest text-slate-400 mb-3 ml-2 text-left text-left text-left">Institution Identity</label><input type="email" placeholder="student@university.edu" className="w-full bg-slate-50 border-2 border-slate-100 p-6 rounded-3xl outline-none focus:border-indigo-500 focus:bg-white transition-all font-bold text-indigo-950 text-lg text-left" defaultValue="demo@college.edu" required /></div>
            <div className="text-left"><label className="block text-[10px] font-black uppercase tracking-widest text-slate-400 mb-3 ml-2 text-left text-left text-left">Cryptographic Key</label><input type="password" placeholder="••••••••" className="w-full bg-slate-50 border-2 border-slate-100 p-6 rounded-3xl outline-none focus:border-indigo-500 focus:bg-white transition-all font-bold text-indigo-950 text-lg text-left" defaultValue="password" required /></div>
            <button className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-black py-7 rounded-[2.5rem] shadow-2xl transition-all active:scale-[0.98] text-lg uppercase tracking-widest text-center">Authorize Session</button>
            <button type="button" onClick={() => setView('counselor')} className="w-full bg-slate-900 text-white font-black py-5 rounded-[2.5rem] text-xs uppercase tracking-widest hover:bg-black transition-all text-center">Practitioner Access</button>
          </form>
        </div>
      </div>
    );
    case 'consent': return (
      <div className="min-h-screen flex items-center justify-center p-8 bg-[#F8FAFC] text-center">
        <div className="w-full max-w-2xl bg-white p-20 rounded-[5rem] shadow-2xl border border-slate-100 text-center text-center animate-in zoom-in duration-500">
          <div className="w-24 h-24 bg-emerald-100 text-emerald-600 rounded-[2rem] flex items-center justify-center mx-auto mb-10 shadow-lg text-center"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-12 h-12 text-center"><path fillRule="evenodd" d="M12 2.25c-5.385 0-9.75 4.365-9.75 9.75s4.365 9.75 9.75 9.75 9.75-4.365 9.75-9.75S17.385 2.25 12 2.25Zm3.36 10.19a.75.75 0 1 0-1.22-.872l-3.236 4.53L9.53 12.22a.75.75 0 0 0-1.06 1.06l2.25 2.25a.75.75 0 0 0 1.14-.094l3.75-5.25Z" clipRule="evenodd" /></svg></div>
          <h2 className="text-5xl font-black text-slate-900 mb-6 tracking-tight leading-none text-center text-center text-center">Authorization</h2>
          <p className="text-slate-500 mb-12 font-medium leading-relaxed text-xl text-center text-center text-center text-center">Entering secure medical vault. AES-256 encrypted data blocks. Proceed?</p>
          <div className="space-y-4 text-center text-center"><button onClick={() => handleConsent(true)} className="w-full bg-emerald-600 text-white font-black py-6 rounded-[2.5rem] shadow-2xl shadow-emerald-100 hover:bg-emerald-700 transition-all uppercase tracking-widest text-lg text-center">I Authorize</button><button onClick={() => handleConsent(false)} className="w-full text-slate-400 font-bold hover:text-slate-600 transition-colors py-4 text-center text-center text-center">Cancel</button></div>
        </div>
      </div>
    );
    case 'logs': return (
      <div className="max-w-4xl mx-auto py-24 px-10 animate-in fade-in duration-500 text-left text-left">
        <button onClick={() => setView('dashboard')} className="mb-12 text-indigo-600 font-black flex items-center gap-3 hover:gap-5 transition-all uppercase text-[11px] tracking-widest text-left text-left">&larr; Return to Workspace</button>
        <GlassCard title="Security Ledger" subtitle="Immutable access logs">
          <div className="space-y-6 max-h-[600px] overflow-y-auto pr-6 text-left text-left">{logs.map(log => (<div key={log.id} className="flex flex-col md:flex-row md:items-center gap-6 p-8 rounded-3xl bg-slate-50 border border-slate-100 group transition-all hover:bg-white text-left text-left text-left text-left text-left"><div className="w-48 shrink-0 font-mono text-[10px] text-slate-400 group-hover:text-indigo-600 transition-colors text-left text-left">{new Date(log.timestamp).toLocaleString()}</div><div className={`font-black w-28 shrink-0 uppercase tracking-[0.2em] text-[10px] text-left text-left ${log.actor === 'Counselor' ? 'text-rose-600' : 'text-indigo-600'}`}>{log.actor}</div><div className="text-slate-800 font-bold flex-1 text-sm text-left text-left text-left">{log.details}</div></div>))}</div>
        </GlassCard>
      </div>
    );
    default: return null;
  }
}
