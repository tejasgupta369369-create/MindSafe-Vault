
import { RiskLevel } from '../types';

export interface RiskCalculationResult {
  score: number;
  level: RiskLevel;
  needsAdaptiveQuestions: boolean;
}

/**
 * PRO CLINICAL RISK ENGINE
 * Weighting distribution for holistic mental wellness assessment:
 * Mood (20%), Stress (20%), Sleep (15%), Anxiety (20%), Energy (15%), Social (10%)
 */
export const calculateRisk = (
  mood: number, 
  stress: 'low' | 'medium' | 'high', 
  sleep: number,
  anxiety: number,
  energy: number,
  social: 'isolated' | 'moderate' | 'connected'
): RiskCalculationResult => {
  // Normalize variables to 0-100 scale (where 100 is "high risk/distress")
  
  // 1. Mood (1 is bad, 5 is good)
  const moodRisk = (5 - mood) * 25; 

  // 2. Stress
  const stressMap = { low: 0, medium: 50, high: 100 };
  const stressRisk = stressMap[stress];

  // 3. Sleep (Ideally 8hrs)
  let sleepRisk = 0;
  if (sleep < 6) sleepRisk = 100;
  else if (sleep < 7) sleepRisk = 60;
  else if (sleep > 9) sleepRisk = 20; // Oversalience risk

  // 4. Anxiety (1-10, 10 is bad)
  const anxietyRisk = (anxiety - 1) * 11.11;

  // 5. Energy (1-10, 1 is bad/low)
  const energyRisk = (10 - energy) * 11.11;

  // 6. Social
  const socialMap = { isolated: 100, moderate: 40, connected: 0 };
  const socialRisk = socialMap[social];

  // Weighted sum
  const totalScore = Math.round(
    (moodRisk * 0.20) + 
    (stressRisk * 0.20) + 
    (sleepRisk * 0.15) +
    (anxietyRisk * 0.20) +
    (energyRisk * 0.15) +
    (socialRisk * 0.10)
  );

  let level: RiskLevel = 'Low';
  if (totalScore >= 70) level = 'High';
  else if (totalScore >= 40) level = 'Moderate';

  return {
    score: totalScore,
    level,
    needsAdaptiveQuestions: totalScore >= 40 || anxiety >= 7 || mood <= 2
  };
};
