
import { User, CheckInEntry, AccessLog, SharingToken, CounselorFeedback, PatientQuestion } from '../types';
import { calculateRisk } from './riskEngine';
import { VaultEncryption } from './encryption';

class MockVaultAPI {
  private users: User[] = [];
  private logs: AccessLog[] = [];
  private tokens: SharingToken[] = [];
  private vaults: Record<string, string> = {}; 
  private feedback: Record<string, CounselorFeedback[]> = {};
  private questions: Record<string, PatientQuestion[]> = {};

  constructor() {
    const demoUser: User = {
      id: 'STU-9902',
      email: 'demo@college.edu',
      hasConsented: false,
      vaultKey: 'demo-secret-key-123'
    };
    this.users.push(demoUser);
    this.logAction('System', 'MindSafe Vault Pro+ Dual-Channel Sync Initialized.');
    
    // Seed professional historical data
    const historicalData = [
      { mood: 4, stress: 'low', sleepHours: 8, anxietyLevel: 2, energyLevel: 8, socialConnection: 'connected', ts: Date.now() - 86400000 * 3 },
      { mood: 3, stress: 'medium', sleepHours: 7, anxietyLevel: 4, energyLevel: 6, socialConnection: 'moderate', ts: Date.now() - 86400000 * 2 },
      { mood: 2, stress: 'high', sleepHours: 5, anxietyLevel: 7, energyLevel: 3, socialConnection: 'isolated', ts: Date.now() - 86400000 * 1 }
    ];

    const entries = historicalData.map((d, i) => {
      const risk = calculateRisk(d.mood, d.stress as any, d.sleepHours, d.anxietyLevel, d.energyLevel, d.socialConnection as any);
      return {
        id: `SEED-${i}`,
        timestamp: d.ts,
        ...d,
        riskScore: risk.score,
        riskLevel: risk.level,
        isAdaptive: risk.needsAdaptiveQuestions
      } as CheckInEntry;
    });

    this.vaults[demoUser.id] = VaultEncryption.encrypt(entries, demoUser.vaultKey);
    this.feedback[demoUser.id] = [{
      id: 'FEED-INIT',
      timestamp: Date.now() - 86400000,
      counselorName: 'Julian Vance',
      reviewerTitle: 'PhD, Clinical Lead',
      reviewerSpecialty: 'Cognitive Behavioral Therapy',
      reviewerDepartment: 'Behavioral Health Unit',
      content: 'I noticed your sleep patterns have been irregular. I recommend a temporary caffeine reset and 15 minutes of light morning activity.',
      interventions: ['Sleep Hygiene', 'Morning Sunlight']
    }];
    this.questions[demoUser.id] = [];
  }

  private logAction(actor: AccessLog['actor'], details: string) {
    const log: AccessLog = {
      id: `LOG-${Math.random().toString(36).substr(2, 6).toUpperCase()}`,
      timestamp: Date.now(),
      action: details.split(' ')[0],
      actor,
      details
    };
    this.logs.push(log);
  }

  async login(email: string): Promise<User | null> {
    const user = this.users.find(u => u.email === email);
    if (user) {
      this.logAction('Student', `Authenticated vault session for ${email}.`);
      return { ...user };
    }
    return null;
  }

  async updateConsent(userId: string, status: boolean): Promise<boolean> {
    const user = this.users.find(u => u.id === userId);
    if (user) {
      user.hasConsented = status;
      this.logAction('Student', `Updated Privacy Protocol Consent to: ${status}.`);
      return true;
    }
    return false;
  }

  async submitCheckIn(userId: string, data: any): Promise<CheckInEntry> {
    const user = this.users.find(u => u.id === userId)!;
    const { score, level, needsAdaptiveQuestions } = calculateRisk(
      data.mood, data.stress, data.sleepHours, data.anxietyLevel, data.energyLevel, data.socialConnection
    );
    
    const entry: CheckInEntry = {
      id: `ENT-${Date.now()}`,
      timestamp: Date.now(),
      ...data,
      riskScore: score,
      riskLevel: level,
      isAdaptive: needsAdaptiveQuestions
    };

    const currentVault = this.vaults[userId] ? VaultEncryption.decrypt(this.vaults[userId], user.vaultKey) : [];
    const updatedVault = [...currentVault, entry];
    this.vaults[userId] = VaultEncryption.encrypt(updatedVault, user.vaultKey);

    this.logAction('System', `Encryption confirmed for record ${entry.id}. Risk assessed as ${level}.`);
    return entry;
  }

  async submitPatientQuestion(userId: string, content: string): Promise<PatientQuestion> {
    if (!this.questions[userId]) this.questions[userId] = [];
    const question: PatientQuestion = {
      id: `QUE-${Date.now()}`,
      timestamp: Date.now(),
      content,
      isAnswered: false
    };
    this.questions[userId].push(question);
    this.logAction('Student', `Encrypted clinical inquiry ${question.id} queued for review.`);
    return question;
  }

  async getDashboard(userId: string): Promise<{entries: CheckInEntry[], feedback: CounselorFeedback[], questions: PatientQuestion[]}> {
    const user = this.users.find(u => u.id === userId);
    if (!user) return { entries: [], feedback: [], questions: [] };
    const entries = this.vaults[userId] ? VaultEncryption.decrypt(this.vaults[userId], user.vaultKey) : [];
    const feed = this.feedback[userId] || [];
    const q = this.questions[userId] || [];
    return { entries, feedback: feed, questions: q };
  }

  async getLogs(): Promise<AccessLog[]> {
    return [...this.logs].reverse();
  }

  async createToken(userId: string): Promise<string> {
    const token = Math.random().toString(36).substr(2, 10).toUpperCase().replace(/(.{5})/g, '$1-').slice(0, -1);
    this.tokens.push({ token, ownerId: userId, expiresAt: Date.now() + 3600000 });
    this.logAction('Student', `Generated temporary clinical session key: ${token}.`);
    return token;
  }

  async getCounselorView(token: string): Promise<any> {
    const tokenObj = this.tokens.find(t => t.token === token);
    if (!tokenObj || tokenObj.expiresAt < Date.now()) throw new Error("Key Expired");

    const userId = tokenObj.ownerId;
    const user = this.users.find(u => u.id === userId)!;
    const entries: CheckInEntry[] = VaultEncryption.decrypt(this.vaults[userId], user.vaultKey) || [];
    const pendingQuestions = (this.questions[userId] || []).filter(q => !q.isAnswered);

    this.logAction('Counselor', `Clinical portal access via key ${token}.`);
    return {
      riskTrend: entries.map(e => ({ timestamp: e.timestamp, score: e.riskScore })),
      currentRiskLevel: entries.length > 0 ? entries[entries.length - 1].riskLevel : 'Low',
      lastCheckIn: entries.length > 0 ? entries[entries.length - 1].timestamp : 0,
      entriesCount: entries.length,
      ownerId: userId,
      pendingQuestions
    };
  }

  async submitCounselorFeedback(
    userId: string, 
    counselorName: string, 
    reviewerTitle: string,
    reviewerSpecialty: string,
    reviewerDepartment: string,
    content: string, 
    interventions: string[],
    linkedQuestionId?: string
  ): Promise<void> {
    if (!this.feedback[userId]) this.feedback[userId] = [];
    
    // Mark question as answered if applicable
    if (linkedQuestionId && this.questions[userId]) {
      const q = this.questions[userId].find(que => que.id === linkedQuestionId);
      if (q) q.isAnswered = true;
    }

    this.feedback[userId].push({
      id: `RVW-${Date.now()}`,
      timestamp: Date.now(),
      counselorName,
      reviewerTitle,
      reviewerSpecialty,
      reviewerDepartment,
      content,
      interventions,
      linkedQuestionId
    });
    this.logAction('Counselor', `Secure clinical review committed to patient ${userId} by ${counselorName}, ${reviewerTitle}.`);
  }
}

export const API = new MockVaultAPI();
