
# 🛡️ MindSafe Vault
**Privacy-First Mental Health Early-Warning System (Hackathon Demo)**

MindSafe Vault is a serious healthcare software prototype designed for university students. It prioritizes **Data Sovereignty** and **Cryptographic Privacy** using a student-controlled medical data vault.

## 🏗️ High-Level Architecture
MindSafe Vault operates on a **Zero-Knowledge-Lite** model:
1.  **Frontend (React/ES6)**: Handles all cryptographic operations. Qualitative data (reflections) is encrypted *before* transmission.
2.  **Logic (Heuristic Risk Engine)**: Uses a transparent, rule-based weighted algorithm to detect stress patterns.
3.  **Vault (Database/Mock)**: Stores data in base64-encoded encrypted blocks.
4.  **Privacy Proxy**: Redacts sensitive text strings during Counselor authorization flows.
5.  **Immutable Ledger**: Tracks every access event for HIPAA/FERPA compliance simulation.

## 📂 Project Structure
```text
mindsafe-vault/
├── main.py                # FastAPI Backend (Production Specification)
├── index.html             # Entry point (Tailwind + React 19)
├── App.tsx                # Core React Dashboard & UI Logic
├── types.ts               # Global Type Definitions
├── services/
│   ├── encryption.ts      # WebCrypto AES-256 Wrappers
│   ├── riskEngine.ts      # Weighted Heuristic Algorithm
│   └── mockApi.ts         # Stateful Demo Persistence
└── README.md              # Documentation
```

## 🧠 Risk Scoring Logic (Technical)
The engine calculates a `risk_score` (0-100) using three primary variables:
-   **Mood (40%)**: Scale 1-5. Lower mood correlates to non-linear score increase.
-   **Stress (40%)**: Qualitative mapping (Low=0, Med=50, High=100).
-   **Sleep (20%)**: Variance from target 8-hour window. <6hrs triggers maximum impact.

**Adaptive Questioning**: Triggers if `risk_score` ≥ 40, collecting contextual data like social withdrawal or physical symptoms.

## 🚀 Demo Flow
1.  **Student Entry**: Log in at the student gateway.
2.  **Sovereignty Check**: Grant explicit consent for data collection.
3.  **Secure Check-in**: 
    -   Enter a "Low Risk" day (Happy, Low Stress, 8hrs sleep).
    -   Observe the "Low Risk" trend.
    -   Enter a "High Risk" day (Sad, High Stress, 4hrs sleep).
    -   Complete the **Adaptive Context** questions.
4.  **The Ledger**: Inspect the "Audit Logs" to see your interactions recorded.
5.  **Authorized Sharing**: Generate a 1-hour access token for your counselor.
6.  **Counselor Portal**: Paste the token to see the redacted trend view (No text reflections visible).

## 🔒 Security Assumptions
-   This demo uses a base64 simulation of AES-256 for local execution.
-   In a VPS/Production environment, the `vaultKey` would be derived from the user's password via Argon2 or PBKDF2.
-   All API endpoints require Bearer Token authorization.
