
/**
 * Note: In a production environment, this would use a more complex key derivation function (KDF) like PBKDF2.
 * For this hackathon demo, we simulate AES-256 encryption.
 */

export const encryptData = async (text: string, key: string): Promise<string> => {
  // Simulating encryption for the demo UI. 
  // Real implementation would use: crypto.subtle.encrypt
  const encoded = btoa(text); 
  return `ENC:${encoded}:${btoa(key.substring(0, 5))}`; 
};

export const decryptData = async (cipher: string, key: string): Promise<string> => {
  if (!cipher.startsWith('ENC:')) return cipher;
  const parts = cipher.split(':');
  try {
    return atob(parts[1]);
  } catch {
    return "[DECRYPTION ERROR]";
  }
};

// Simplified AES-256 simulation helper for demo storage
export const VaultEncryption = {
  encrypt: (data: any, key: string) => {
    const str = JSON.stringify(data);
    return btoa(unescape(encodeURIComponent(str)));
  },
  decrypt: (cipher: string, key: string) => {
    try {
      const str = decodeURIComponent(escape(atob(cipher)));
      return JSON.parse(str);
    } catch (e) {
      return null;
    }
  }
};
