
export type RiskLevel = 'Low' | 'Moderate' | 'High';

export interface User {
  id: string;
  email: string;
  hasConsented: boolean;
  vaultKey: string;
}

export interface PatientQuestion {
  id: string;
  timestamp: number;
  content: string; // Encrypted in real use
  isAnswered: boolean;
}

export interface CounselorFeedback {
  id: string;
  timestamp: number;
  counselorName: string;
  reviewerTitle: string;        // e.g., MD, PhD, LCSW
  reviewerSpecialty: string;    // e.g., CBT, Trauma, Sleep
  reviewerDepartment: string;   // e.g., University Health Services
  content: string;
  interventions?: string[];
  linkedQuestionId?: string;    // Pairs feedback to a specific patient question
}

export interface CheckInEntry {
  id: string;
  timestamp: number;
  mood: number; // 1-5
  stress: 'low' | 'medium' | 'high';
  sleepHours: number;
  anxietyLevel: number; // 1-10
  energyLevel: number; // 1-10
  socialConnection: 'isolated' | 'moderate' | 'connected';
  reflection?: string; // Encrypted
  riskScore: number; // 0-100
  riskLevel: RiskLevel;
  isAdaptive: boolean;
}

export interface AccessLog {
  id: string;
  timestamp: number;
  action: string;
  actor: 'Student' | 'Counselor' | 'System';
  details: string;
}

export interface SharingToken {
  token: string;
  expiresAt: number;
  ownerId: string;
}

export interface CounselorViewData {
  riskTrend: { timestamp: number; score: number }[];
  currentRiskLevel: RiskLevel;
  lastCheckIn: number;
  entriesCount: number;
  ownerId: string;
  pendingQuestions: PatientQuestion[];
}
